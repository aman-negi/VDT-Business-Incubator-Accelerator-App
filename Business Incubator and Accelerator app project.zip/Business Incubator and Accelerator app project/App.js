import React from 'react';

import LearnOrWorkScreen from './src/screens/LearnOrWorkScreen';
import SignUpScreen from './src/screens/SignUpScreen';
import SignInScreen from './src/screens/SignInScreen';
import LoadingScreen from './src/screens/LoadingScreen';
import VariousBusinessScreen from './src/screens/work/VariousBusinesscreen';
import ToolsScreen from './src/screens/work/ToolsScreen';
import BusinessRegistrationScreen from './src/screens/work/BusinessRegistrationScreen';
import BusinessEvaluationScreen from './src/screens/work/BusinessEvaluationScreen';
import ProfileScreen from './src/screens/ProfileScreen';

import LearnMainScreen from './src/screens/learn/LearnMainScreen';


import { createAppContainer} from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';



import * as firebase from 'firebase';




var firebaseConfig = {
  apiKey: "AIzaSyBMQkTwsOc50AD2mi2jUlrz5UaVuPeaiuU",
  authDomain: "vdtbusinessincubator.firebaseapp.com",
  databaseURL: "https://vdtbusinessincubator.firebaseio.com",
  projectId: "vdtbusinessincubator",
  storageBucket: "vdtbusinessincubator.appspot.com",
  messagingSenderId: "440645300969",
  appId: "1:440645300969:web:c9d15f23c0bfc8b7433678",
  measurementId: "G-MGRHZ4YZSG"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);



const MainNavigator = createStackNavigator(
  {
    Loading : {screen : LoadingScreen},
    SignIn: {screen :SignInScreen},
    SignUp : {screen : SignUpScreen},
    LearnOrWork : {screen : LearnOrWorkScreen},
    LearnMain: {screen : LearnMainScreen},
    VariousBusiness : {screen : VariousBusinessScreen},
    BusinessRegistration : {screen : BusinessRegistrationScreen},
    BusinessEvaluation : {screen : BusinessEvaluationScreen},
    Tools : {screen : ToolsScreen},
    Profile : { screen : ProfileScreen}
  },
  {
    //launcher screen
    initialRouteName: "Loading"
  
  
  }, 

)

//create app container
const App = createAppContainer(MainNavigator);
export default App;